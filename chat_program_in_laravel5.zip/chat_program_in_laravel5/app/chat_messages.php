<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class chat_messages extends Model
{
    //
    protected $table = "chat_messages";
    
    public $primaryKey = "id";
    
    public $timestamps = true;
    
    public function posts()
    {
        return 0;
    }
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class chat_messages extends Model
{
    //
}

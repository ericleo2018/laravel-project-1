<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Contracts\View\View;
use App\chat_messages as chat_messages_Modal;

class PagesController extends Controller
{
    //
    public function index()
    {

		$view = view('pages.login');
		return $view;		
	}    
    
    public function process_login()
    {
		session_start();
				
        if (isset($_REQUEST['userid']))
        {
			$userid = $_REQUEST['userid'];
		}
		else
		{
			$userid = "none";
		}

		$_SESSION["userid"] = $userid;	
				
		$data = array(
			"userid"=>$userid,
		);
		
		$view = view('pages.page1', ['data' => $data]);
		return $view;	
		
		//return view('pages.page1')->with('data', $data);
	}    
	    
    public function show_chat_page()
    {


		$userid = "ericleo";
	
		
		$data = array(
			"userid"=>$userid,
		);
		
		$view = view('pages.page1', ['data' => $data]);
		return $view;
		
		//return view('pages.page1', ['userid' => 'Victoria']);

	}
	
	public function receive()
    {
        if (isset($_REQUEST['userid']))
        {
			$userid = $_REQUEST['userid'];
		}
		else
		{
			$userid = "none";
		}
		
        if (isset($_REQUEST['message']))
        {
			$message = $_REQUEST['message'];
		}
		else
		{
			$message = "none";
		}
		
		$chat_messages_Modal_Obj = new chat_messages_Modal();
		// INSERT new message
		$chat_messages_Modal_Obj->message = $userid . "> " . $message;
        $chat_messages_Modal_Obj->save();
		
		
		//~ // RETRIEVE LAST 10 MESSAGES	
        //~ 
        //~ $offset = 0;
        //~ $limit  = 10;
	    //~ $chat_messages_json = $chat_messages_Modal_Obj->skip($offset*$limit)->take($limit)->get();
		//~ 
		//~ $json = '[{
			//~ "userid":'.$userid.',
			//~ "message":'.$message.',		
		//~ }]';
		//~ 
		//~ //$result_string = var_dump(json_decode($chat_messages_json, true));
		//~ $result_string = '';
		//~ 
		//~ foreach ($chat_messages_json as $record)
		//~ {
			//~ $result_string .= $record['message'] . '<br>';
		//~ }

		$result_string = "STATUS OK";					
		return $result_string;
		
		//return view('pages.page1', ['userid' => 'Victoria']);

	}
	
	public function get_messages()
	{
		$chat_messages_Modal_Obj = new chat_messages_Modal();
		
		// RETRIEVE LAST 20 MESSAGES	
        
        $offset = 0;
        $limit  = 20;
	    //$chat_messages_json = $chat_messages_Modal_Obj->skip($offset*$limit)->take($limit)->get();
		$chat_messages_json = $chat_messages_Modal_Obj->orderBy('id', 'desc')->take($limit)->get();
		
		$records_arr = array();
		foreach ($chat_messages_json as $record)
		{
			$one_record_arr = array(
			    'id'=>$record['id'],
				'message'=>$record['message'],
			);
			array_push($records_arr, $one_record_arr);
		}
		
		
		krsort($records_arr);
		
		$result_string = '';
		
		foreach ($records_arr as $record)
		{
			$result_string .= $record['message'] ."<br>" ;
		}

							
		return $result_string;		
	}
}

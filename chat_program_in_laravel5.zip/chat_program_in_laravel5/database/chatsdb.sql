-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 09, 2018 at 08:54 PM
-- Server version: 5.5.57-0ubuntu0.14.04.1
-- PHP Version: 5.6.31-6+ubuntu14.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chatsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE IF NOT EXISTS `chat_messages` (
  `id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `message` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`id`, `created_at`, `updated_at`, `message`) VALUES
(3, '2018-11-09 03:48:54', '2018-11-09 03:48:54', 'Eric> hello Darling'),
(4, '2018-11-09 03:49:30', '2018-11-09 03:49:30', 'Eric> Wow!!!'),
(5, '2018-11-09 03:49:39', '2018-11-09 03:49:39', 'Eric> Hey there.'),
(6, '2018-11-09 03:50:03', '2018-11-09 03:50:03', 'Danny> Hi Eric. How are you?'),
(7, '2018-11-09 03:50:23', '2018-11-09 03:50:23', 'Eric> Hi Danny. I am fine.'),
(8, '2018-11-09 03:58:06', '2018-11-09 03:58:06', 'Eric> What time is it?'),
(9, '2018-11-09 03:58:23', '2018-11-09 03:58:23', 'Danny> 3:00 PM.'),
(10, '2018-11-09 04:02:44', '2018-11-09 04:02:44', 'Eric> '),
(11, '2018-11-09 04:02:48', '2018-11-09 04:02:48', 'Eric> OK'),
(12, '2018-11-09 04:03:13', '2018-11-09 04:03:13', 'Danny> Have you seen the movie "Top Gun" ?'),
(13, '2018-11-09 04:03:21', '2018-11-09 04:03:21', 'Eric> Yes.'),
(20, '2018-11-09 04:07:26', '2018-11-09 04:07:26', 'Eric> YES'),
(21, '2018-11-09 04:14:26', '2018-11-09 04:14:26', 'Danny> That''s cool.'),
(22, '2018-11-09 04:15:04', '2018-11-09 04:15:04', 'Eric> I went with my girlfriend.'),
(23, '2018-11-09 04:15:37', '2018-11-09 04:15:37', 'Danny> I see.'),
(24, '2018-11-09 04:15:45', '2018-11-09 04:15:45', 'Danny> What is her name?'),
(25, '2018-11-09 04:16:53', '2018-11-09 04:16:53', 'Eric> hey'),
(26, '2018-11-09 04:35:10', '2018-11-09 04:35:10', 'Danny> Linda.'),
(27, '2018-11-09 04:43:23', '2018-11-09 04:43:23', 'Eric> Linda who?'),
(28, '2018-11-09 04:45:13', '2018-11-09 04:45:13', 'Danny> Linda my cousin. She wants to see you.'),
(29, '2018-11-09 04:45:24', '2018-11-09 04:45:24', 'Eric> Oh yeah?'),
(30, '2018-11-09 04:45:36', '2018-11-09 04:45:36', 'Danny> Yeah!'),
(31, '2018-11-09 04:45:53', '2018-11-09 04:45:53', 'Danny> Are you game?'),
(32, '2018-11-09 04:46:12', '2018-11-09 04:46:12', 'Eric> Sure.'),
(33, '2018-11-09 04:46:39', '2018-11-09 04:46:39', 'Eric> 1'),
(34, '2018-11-09 04:46:43', '2018-11-09 04:46:43', 'Eric> 2'),
(35, '2018-11-09 04:46:46', '2018-11-09 04:46:46', 'Eric> 3'),
(36, '2018-11-09 04:46:51', '2018-11-09 04:46:51', 'Eric> 4'),
(37, '2018-11-09 04:46:55', '2018-11-09 04:46:55', 'Eric> 5'),
(38, '2018-11-09 04:50:49', '2018-11-09 04:50:49', 'Eric> 6');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(4, '2018_11_09_093355_chat_messages', 2),
(5, '2014_10_12_000000_create_users_table', 3),
(6, '2014_10_12_100000_create_password_resets_table', 3),
(7, '2018_11_09_092733_create_chat_messages_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

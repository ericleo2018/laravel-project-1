<!DOCTYPE html>
<html \>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Chat Program</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <style>
			.chat_div
			{
				width: 800px;
				height: 400px;
				background-color: #F4F4C8;
				border: solid blue 2px;
			}
        </style>
        <script>
            function when_send_button_was_clicked()
            {
				userid = document.getElementById("userid").value;
				message = document.getElementById("message_textbox").value;
				//alert(userid + ":\n" + message);
				$.ajax({ 
					     url: "/receive", 
						 method:"GET",
					     dataType: 'text',
					     data: {
							    "userid":userid,
							    "message":message,
						 },
					     success: function(result) {
					                  //$("#chat_div").html(result);
				                  },
				                  
				       });
				       
				// Clear the message text-box.
				document.getElementById("message_textbox").value = "";  
			}

            function get_messages()
            {
				$.ajax({ 
					     url: "/get_messages", 
						 method:"GET",
					     dataType: 'text',
					     data: {
						 },
					     success: function(result) {
					                  $("#chat_div").html(result);
				                  },
				                  
				       });
			}        
			
			// How many milliseconds.
			var how_many_milliseconds = 750;
			setInterval(function(){ get_messages(); }, how_many_milliseconds);
			
			

        </script>
    </head>
    <body>
		<div>
       <h1>Chat Program</h1>
       <h2>by Eric Leo</h2>
       </div>
       
       <div id="chat_div" class="chat_div">

       </div>
       <form name="the_form" method="post" action="" onsubmit="return false;">
		   <input type="hidden" name="userid" id="userid" value="<?php echo $data['userid'] ?>" />
		   <input type="text" name="message_textbox" id="message_textbox" value="" size="40" placeholder="Type your message here" />
           <input type="button" name="send_button" value="Send" onclick="when_send_button_was_clicked();"/>
       </form>
    </body>
</html>

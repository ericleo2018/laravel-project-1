<!DOCTYPE html>
<html \>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Chat Program</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <style>
			.login_div
			{
				width: 400px;
				height: 100px;
				padding: 10px 10px 10px 10px;
				background-color: #90EE90;
				border: solid #008000 2px;
			}
        </style>
        <script>
       
        </script>
    </head>
    <body>
	<div align="center">
       <h1>Chat Program</h1>
       <h2>by Eric Leo</h2>
       <h1>LOGIN</h1>
      
       
       <div id="login_div" class="login_div">
       <form name="the_form" method="GET" action="/process_login">
		   <input type="hidden" name="_token" value="{{ csrf_token() }}">
		   User-id: <input type="text" name="userid" id="userid" value="" placeholder="Please enter your user-id"/>
          <input type="submit" name="submit_form_button" value="Login"/>
       </form>
       </div>
       
       
	</div>
    </body>
</html>
